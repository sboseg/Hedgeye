$(document).ready(function () {
	

		if ($(window).width() <= 480) {
			$('#sroach_copy, #nhowe_copy').removeClass('text-right col-xs-8 col-xs-offset-1').addClass('col-xs-12');
			$('#kbarnett_copy, #jchanos_copy').removeClass('col-xs-8').addClass('col-xs-12');
	  }

	
});



